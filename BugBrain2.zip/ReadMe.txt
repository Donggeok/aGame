Welcome to Bug Brain 2

This is the full version of Bug Brain.

Demo Done
*********
If you have already completed the two levels in the demo
version and you don't want to do them again, click on the
"Bug Brain" title above the signpost on the opening screen.
Enter "demodone" (no quotes) in the password box and press OK. 

The next set of experiments is back in the lab, so click on
the lab sign to continue. You should now see two red books.
Click on the one on the bench - this is always the current one.

You also now have access to the workshop where you can make
your own worlds. Initially, you only have the Lady bug and
aphid to work with. As you solve the problems you will obtain
more things to play with.


Help
****
Help is available in the program from a manual sitting on the
shelf next to the test instruments. Click on the blue book on
the shelf to open it. Included in the manual are hints which
may (or may not) help and some solutions.

Help is also available from the web site:
www.biologic.com.au\bugbrain
or from the author:
Tom.Morton@bigpond.com


Large Font / Small Font
***********************
The program will work with the display set to Large Font. Because
the window resizes to accomodate the font, some of the graphics
will be slightly misaligned. This is of no importance except that
it annoys me and I just wanted to point out that it is not my fault.

Test Controls
*************
Buttons to test, reset and run the world appear in the test window
when it is maximized. To change when the buttons appear, right click
on the brain, select Properties from the menu and click on the
Display tab.

